names = "melanogaster,simulans,yakuba,ananassae"
species = names.split(",")
print(str(species))
