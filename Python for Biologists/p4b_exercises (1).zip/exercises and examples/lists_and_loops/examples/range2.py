for number in range(3, 8):
    print(number)
