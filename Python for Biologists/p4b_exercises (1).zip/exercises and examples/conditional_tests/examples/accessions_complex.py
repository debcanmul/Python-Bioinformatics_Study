accs = ['ab56', 'bh84', 'hv76', 'ay93', 'ap97', 'bd72']
for acc in accs:
	if (acc.startswith('a') or acc.startswith('b')) and acc.endswith('4'):
		print(acc)


