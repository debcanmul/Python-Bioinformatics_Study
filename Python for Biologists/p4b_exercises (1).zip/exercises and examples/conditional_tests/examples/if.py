my_number = 3
if my_number < 5:
    print("Hello")


