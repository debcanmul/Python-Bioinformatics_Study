accs = ['ab56', 'bh84', 'hv76', 'ay93', 'ap97', 'bd72']
for acc in accs:
	if acc.startswith('a') and not acc.endswith('6'):
		print(acc)
