import re

re.search(my_pattern, my_string)


