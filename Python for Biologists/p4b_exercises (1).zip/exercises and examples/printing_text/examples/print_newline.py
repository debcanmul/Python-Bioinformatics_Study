# how to include a new line in the middle of a string
print("Hello\nworld")
