# this is a comment, it will be ignored by the computer
print("Comments are very useful!")
