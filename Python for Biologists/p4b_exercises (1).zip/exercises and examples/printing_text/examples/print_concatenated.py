my_dna = "AATT" + "GGCC"
print(my_dna)
