my_dna = "ATGC"
# print my_dna in lower case
print(my_dna.lower())
