print("She said, 'Hello world'")
print('He said, "Hello world"')
