prin("Hello world")
