my_file_name = "dna.txt"
my_file = open(my_file_name)
print(my_file)
