my_file = open("dna.txt")
file_contents = my_file.read()
print(file_contents)
